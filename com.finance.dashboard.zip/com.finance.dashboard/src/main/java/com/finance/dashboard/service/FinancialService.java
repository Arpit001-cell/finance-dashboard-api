package com.finance.dashboard.service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // ✅ CHANGED from jakarta

import com.finance.dashboard.dto.request.FinancialRecordDTO;
import com.finance.dashboard.dto.response.FinancialRecordResponseDTO;
import com.finance.dashboard.entity.FinancialRecord;
import com.finance.dashboard.enums.TransactionType;
import com.finance.dashboard.exception.BadRequestException;
import com.finance.dashboard.exception.ResourceNotFoundException;
import com.finance.dashboard.repository.FinancialRecordRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FinancialService {

    private final FinancialRecordRepository recordRepository;

    public FinancialService(FinancialRecordRepository recordRepository) {
        this.recordRepository = recordRepository;
    }

    @Transactional
    public FinancialRecordResponseDTO createRecord(FinancialRecordDTO dto) {
        log.info("Creating financial record of type: {}", dto.getType());

        if (dto.getAmount() == null || dto.getAmount() <= 0) {
            throw new BadRequestException(
                    "Amount must be greater than zero. Received: " + dto.getAmount());
        }

        if (dto.getDate() != null && dto.getDate().isAfter(LocalDate.now())) {
            throw new BadRequestException(
                    "Record date must not be in the future. Received: " + dto.getDate());
        }

        FinancialRecord saved = recordRepository.save(mapToEntity(dto));
        log.info("Financial record created with id: {}", saved.getId());

        return mapToDTO(saved);
    }

    @Transactional(readOnly = true) // ✅ Now works correctly
    public List<FinancialRecordResponseDTO> getAllRecords() {
        log.debug("Fetching all financial records");

        return recordRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true) // ✅ Now works correctly
    public FinancialRecordResponseDTO getRecordById(Long id) {
        return mapToDTO(findRecordOrThrow(id));
    }

    @Transactional(readOnly = true) // ✅ Now works correctly
    public List<FinancialRecordResponseDTO> filterRecords(
            LocalDate startDate,
            LocalDate endDate,
            String category,
            TransactionType type) {

        log.debug("Filtering records — startDate={}, endDate={}, category={}, type={}",
                startDate, endDate, category, type);

        if (startDate != null || endDate != null) {
            if (startDate == null || endDate == null) {
                throw new BadRequestException(
                        "Both startDate and endDate must be provided for a date range filter.");
            }
            if (startDate.isAfter(endDate)) {
                throw new BadRequestException(
                        "startDate must not be after endDate. Received: " + startDate + " → " + endDate);
            }
        }

        final LocalDate start    = startDate;
        final LocalDate end      = endDate;
        final String    cat      = (category != null && !category.isBlank()) ? category.trim() : null;
        final TransactionType tx = type;

        return recordRepository.findAll()
                .stream()
                .filter(r -> start == null ||
                        (!r.getDate().isBefore(start) && !r.getDate().isAfter(end)))
                .filter(r -> cat == null || cat.equalsIgnoreCase(r.getCategory()))
                .filter(r -> tx  == null || tx.equals(r.getType()))
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public FinancialRecordResponseDTO updateRecord(Long id, FinancialRecordDTO dto) {
        log.info("Updating financial record with id: {}", id);

        if (dto.getAmount() == null || dto.getAmount() <= 0) {
            throw new BadRequestException(
                    "Amount must be greater than zero. Received: " + dto.getAmount());
        }

        if (dto.getDate() != null && dto.getDate().isAfter(LocalDate.now())) {
            throw new BadRequestException(
                    "Record date must not be in the future. Received: " + dto.getDate());
        }

        FinancialRecord record = findRecordOrThrow(id);

        record.setAmount(dto.getAmount());
        record.setType(dto.getType());
        record.setCategory(dto.getCategory());
        record.setDate(dto.getDate());
        record.setNote(dto.getNote());

        FinancialRecord updated = recordRepository.save(record);
        log.info("Financial record with id {} updated.", updated.getId());

        return mapToDTO(updated);
    }

    @Transactional
    public void deleteRecord(Long id) {
        log.info("Deleting financial record with id: {}", id);

        if (!recordRepository.existsById(id)) {
            throw new ResourceNotFoundException("Financial record not found with id: " + id);
        }

        recordRepository.deleteById(id);
        log.info("Financial record with id {} deleted.", id);
    }

    private FinancialRecord findRecordOrThrow(Long id) {
        return recordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Financial record not found with id: " + id));
    }

    private FinancialRecord mapToEntity(FinancialRecordDTO dto) {
        FinancialRecord record = new FinancialRecord();
        record.setAmount(dto.getAmount());
        record.setType(dto.getType());
        record.setCategory(dto.getCategory());
        record.setDate(dto.getDate());
        record.setNote(dto.getNote());
        return record;
    }

    private FinancialRecordResponseDTO mapToDTO(FinancialRecord record) {
        return FinancialRecordResponseDTO.builder()
                .id(record.getId())
                .amount(record.getAmount())
                .type(record.getType())
                .category(record.getCategory())
                .date(record.getDate())
                .note(record.getNote())
                .build();
    }
}