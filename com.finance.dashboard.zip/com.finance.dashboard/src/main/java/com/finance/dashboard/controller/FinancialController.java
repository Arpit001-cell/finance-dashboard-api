package com.finance.dashboard.controller;


import com.finance.dashboard.dto.request.FinancialRecordDTO;
import com.finance.dashboard.dto.response.ApiResponse;
import com.finance.dashboard.dto.response.FinancialRecordResponseDTO;
import com.finance.dashboard.enums.TransactionType;
import com.finance.dashboard.service.FinancialService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * FinancialController — exposes all financial record endpoints.
 *
 * Base URL : /api/v1/records
 * All responses are wrapped in ApiResponse<T> for consistent structure.
 */
@RestController
@RequestMapping("/api/v1/records")
public class FinancialController {

    private final FinancialService financialService;

    // Constructor injection
    public FinancialController(FinancialService financialService) {
        this.financialService = financialService;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/records
    // Create a new financial record
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Creates a new financial record (INCOME or EXPENSE).
     *
     * @param dto Validated request body
     * @return 201 Created with the persisted record's response DTO
     */
    @PostMapping
    public ResponseEntity<ApiResponse<FinancialRecordResponseDTO>> createRecord(
            @Valid @RequestBody FinancialRecordDTO dto) {

        FinancialRecordResponseDTO created = financialService.createRecord(dto);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Record created successfully.", created));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/records
    // Fetch all financial records
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns all financial records stored in the system.
     *
     * @return 200 OK with list of FinancialRecordResponseDTO
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<FinancialRecordResponseDTO>>> getAllRecords() {

        List<FinancialRecordResponseDTO> records = financialService.getAllRecords();

        return ResponseEntity.ok(
                ApiResponse.success("Records fetched successfully.", records));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/records/filter
    // Filter records by date range, category, and/or type
    // IMPORTANT: Must be declared BEFORE /{id} to avoid route conflict
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Filters financial records by any combination of the following query params.
     * All parameters are optional — omit any to skip that filter.
     *
     * Query params:
     *   startDate  — ISO date, e.g. 2024-01-01  (requires endDate)
     *   endDate    — ISO date, e.g. 2024-03-31  (requires startDate)
     *   category   — exact string, e.g. "Rent"
     *   type       — enum value: INCOME or EXPENSE
     *
     * Example:
     *   GET /api/v1/records/filter?startDate=2024-01-01&endDate=2024-03-31&type=EXPENSE
     *
     * @return 200 OK with filtered list of FinancialRecordResponseDTO
     */
    @GetMapping("/filter")
    public ResponseEntity<ApiResponse<List<FinancialRecordResponseDTO>>> filterRecords(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,

            @RequestParam(required = false) String category,

            @RequestParam(required = false) TransactionType type) {

        List<FinancialRecordResponseDTO> filtered =
                financialService.filterRecords(startDate, endDate, category, type);

        return ResponseEntity.ok(
                ApiResponse.success("Records filtered successfully.", filtered));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUT /api/v1/records/{id}
    // Update all fields of an existing record
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Fully updates an existing financial record.
     *
     * @param id  Path variable — ID of the record to update
     * @param dto Validated request body with all updated fields
     * @return 200 OK with updated FinancialRecordResponseDTO
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<FinancialRecordResponseDTO>> updateRecord(
            @PathVariable Long id,
            @Valid @RequestBody FinancialRecordDTO dto) {

        FinancialRecordResponseDTO updated = financialService.updateRecord(id, dto);

        return ResponseEntity.ok(
                ApiResponse.success("Record updated successfully.", updated));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DELETE /api/v1/records/{id}
    // Hard-delete a financial record
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Permanently deletes a financial record by ID.
     *
     * @param id Path variable — ID of the record to delete
     * @return 200 OK with confirmation message (no body data)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteRecord(@PathVariable Long id) {

        financialService.deleteRecord(id);

        return ResponseEntity.ok(
                ApiResponse.success("Record deleted successfully."));
    }
}