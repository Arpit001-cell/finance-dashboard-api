package com.finance.dashboard.dto.response;



import java.time.Month;
import java.util.Map;

import com.finance.dashboard.enums.TransactionType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DashboardSummaryDTO — the single response object returned by GET /dashboard/summary.
 *
 * Contains:
 *   - Top-level totals     : totalIncome, totalExpenses, netBalance
 *   - Category breakdown   : Map<category, total amount>
 *   - Monthly breakdown    : Map<Month, MonthlySummary> with per-month income, expense, net
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardSummaryDTO {

    // ── Top-level totals ──────────────────────────────────────────────────────
    private double totalIncome;
    private double totalExpenses;
    private double netBalance;
    private long   totalRecords;

    // ── Category-wise totals ──────────────────────────────────────────────────
    // e.g. { "Rent": 25000.0, "Salary": 80000.0, "Groceries": 5000.0 }
    private Map<String, Double> categoryTotals;

    // ── Monthly summary ───────────────────────────────────────────────────────
    // e.g. { JANUARY: { income: 80000, expenses: 30000, net: 50000 } }
    private Map<Month, MonthlySummary> monthlySummary;

    // ── Type-wise totals ──────────────────────────────────────────────────────
    // e.g. { INCOME: 160000.0, EXPENSE: 60000.0 }
    private Map<TransactionType, Double> typeTotals;

    // ─────────────────────────────────────────────────────────────────────────
    // Nested DTO — per-month breakdown
    // ─────────────────────────────────────────────────────────────────────────

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MonthlySummary {
        private double income;
        private double expenses;
        private double net;
        private long   recordCount;
    }
}