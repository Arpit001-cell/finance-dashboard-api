package com.finance.dashboard.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import com.finance.dashboard.security.CustomAccessDeniedHandler;
import com.finance.dashboard.security.CustomAuthenticationEntryPoint;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    private static final String BASE = "/api/v1";

    private final CustomAuthenticationEntryPoint authEntryPoint;
    private final CustomAccessDeniedHandler      accessDeniedHandler;

    public SecurityConfig(CustomAuthenticationEntryPoint authEntryPoint,
                          CustomAccessDeniedHandler accessDeniedHandler) {
        this.authEntryPoint      = authEntryPoint;
        this.accessDeniedHandler = accessDeniedHandler;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(session ->
                    session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth

                // ADMIN only
                .requestMatchers(BASE + "/users/**")
                    .hasRole("ADMIN")

                // ADMIN + ANALYST
                .requestMatchers(HttpMethod.GET,    BASE + "/records/**").hasAnyRole("ADMIN", "ANALYST")
                .requestMatchers(HttpMethod.POST,   BASE + "/records/**").hasAnyRole("ADMIN", "ANALYST")
                .requestMatchers(HttpMethod.PUT,    BASE + "/records/**").hasAnyRole("ADMIN", "ANALYST")
                .requestMatchers(HttpMethod.DELETE, BASE + "/records/**").hasRole("ADMIN")

                // ADMIN + ANALYST + VIEWER
                .requestMatchers(HttpMethod.GET, BASE + "/dashboard/**")
                    .hasAnyRole("ADMIN", "ANALYST", "VIEWER")
                .requestMatchers(BASE + "/dashboard/**")
                    .hasAnyRole("ADMIN", "ANALYST")

                .anyRequest().authenticated()
            )
            .httpBasic(Customizer.withDefaults())
            .exceptionHandling(ex -> ex
                .authenticationEntryPoint(authEntryPoint)
                .accessDeniedHandler(accessDeniedHandler)
            );

        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder encoder) {

        UserDetails admin = User.builder()
                .username("admin")
                .password(encoder.encode("admin123"))
                .roles("ADMIN")
                .build();

        UserDetails analyst = User.builder()
                .username("analyst")
                .password(encoder.encode("analyst123"))
                .roles("ANALYST")
                .build();

        UserDetails viewer = User.builder()
                .username("viewer")
                .password(encoder.encode("viewer123"))
                .roles("VIEWER")
                .build();

        return new InMemoryUserDetailsManager(admin, analyst, viewer);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}