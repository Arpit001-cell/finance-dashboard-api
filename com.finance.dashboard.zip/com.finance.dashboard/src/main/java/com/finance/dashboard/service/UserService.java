package com.finance.dashboard.service;

import com.finance.dashboard.dto.request.UserDTO;
import com.finance.dashboard.dto.response.UserResponseDTO;
import com.finance.dashboard.entity.User;
import com.finance.dashboard.exception.BadRequestException;
import com.finance.dashboard.exception.ResourceNotFoundException;
import com.finance.dashboard.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UserService {

    private final UserRepository  userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository  = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CREATE
    // ─────────────────────────────────────────────────────────────────────────

    @Transactional
    public UserResponseDTO createUser(UserDTO dto) {
        log.info("Creating user with email: {}", dto.getEmail()); // ✅ removed "Object log;" line

        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new BadRequestException("Email is already registered: " + dto.getEmail());
        }

        User user = mapToEntity(dto);
        user.setActive(true);
        user.setPassword(passwordEncoder.encode(dto.getPassword()));

        User saved = userRepository.save(user);
        log.info("User created with id: {}", saved.getId());

        return mapToDTO(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // READ
    // ─────────────────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<UserResponseDTO> getAllUsers() {
        log.debug("Fetching all users");

        return userRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public UserResponseDTO getUserById(Long id) {
        return mapToDTO(findUserOrThrow(id));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UPDATE
    // ─────────────────────────────────────────────────────────────────────────

    @Transactional
    public UserResponseDTO updateUser(Long id, UserDTO dto) {
        log.info("Updating user with id: {}", id);

        User user = findUserOrThrow(id);

        user.setName(dto.getName());
        user.setRole(dto.getRole());

        User updated = userRepository.save(user);
        log.info("User with id {} updated.", updated.getId());

        return mapToDTO(updated);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DEACTIVATE (soft delete)
    // ─────────────────────────────────────────────────────────────────────────

    @Transactional
    public void deactivateUser(Long id) {
        log.info("Deactivating user with id: {}", id);

        User user = findUserOrThrow(id);
        user.setActive(false);
        userRepository.save(user);

        log.info("User with id {} deactivated.", id);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE — lookup helper
    // ─────────────────────────────────────────────────────────────────────────

    private User findUserOrThrow(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found with id: " + id));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE — mapping
    // ─────────────────────────────────────────────────────────────────────────

    private User mapToEntity(UserDTO dto) {
        User user = new User();
        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setPassword(dto.getPassword());
        user.setRole(dto.getRole());
        return user;
    }

    private UserResponseDTO mapToDTO(User user) {
        return UserResponseDTO.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .active(user.isActive())
                .build();
    }
}