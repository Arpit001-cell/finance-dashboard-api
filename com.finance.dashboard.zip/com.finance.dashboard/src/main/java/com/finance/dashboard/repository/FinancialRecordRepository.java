package com.finance.dashboard.repository;

import com.finance.dashboard.entity.FinancialRecord;
import com.finance.dashboard.enums.TransactionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface FinancialRecordRepository extends JpaRepository<FinancialRecord, Long> {

   
    List<FinancialRecord> findByType(TransactionType type);

  
    List<FinancialRecord> findByCategory(String category);

    
    List<FinancialRecord> findByDateBetween(LocalDate startDate, LocalDate endDate);

    
    List<FinancialRecord> findByTypeAndDateBetween(TransactionType type, LocalDate startDate, LocalDate endDate);

   
    List<FinancialRecord> findByCategoryAndDateBetween(String category, LocalDate startDate, LocalDate endDate);

    
    @Query("SELECT COALESCE(SUM(r.amount), 0) FROM FinancialRecord r WHERE r.type = :type")
    double sumAmountByType(@Param("type") TransactionType type);

    
    @Query("SELECT COALESCE(SUM(r.amount), 0) FROM FinancialRecord r WHERE r.type = :type AND r.date BETWEEN :startDate AND :endDate")
    double sumAmountByTypeAndDateBetween(
            @Param("type") TransactionType type,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );
}