package com.finance.dashboard.service;



import com.finance.dashboard.dto.response.DashboardSummaryDTO;
import com.finance.dashboard.dto.response.DashboardSummaryDTO.MonthlySummary;
import com.finance.dashboard.entity.FinancialRecord;
import com.finance.dashboard.enums.TransactionType;
import com.finance.dashboard.repository.FinancialRecordRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Month;
import java.util.*;
import java.util.stream.Collectors;

/**
 * DashboardService — computes all summary aggregations using Java Streams.
 *
 * All aggregations are derived from a single repository fetch to avoid
 * multiple DB round-trips. The data is then sliced in memory via streams.
 *
 * Aggregations produced:
 *   1. Total income
 *   2. Total expenses
 *   3. Net balance  (income - expenses)
 *   4. Total records count
 *   5. Category-wise totals
 *   6. Monthly summary  (income, expenses, net, count per month)
 *   7. Type-wise totals (INCOME vs EXPENSE)
 */
@Slf4j
@Service
public class DashboardService {

    private final FinancialRecordRepository recordRepository;

    public DashboardService(FinancialRecordRepository recordRepository) {
        this.recordRepository = recordRepository;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC — main summary method
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Builds a complete dashboard summary from all financial records.
     *
     * Strategy:
     *   - Fetch all records once from the DB (single query).
     *   - Run all aggregations against the in-memory list using streams.
     *   - Return a single DashboardSummaryDTO containing all results.
     *
     * @return DashboardSummaryDTO with all aggregated metrics
     */
    @Transactional(readOnly = true)
    public DashboardSummaryDTO getSummary() {
        log.info("Building dashboard summary...");

        // Single DB fetch — all aggregations run against this list
        List<FinancialRecord> allRecords = recordRepository.findAll();

        if (allRecords.isEmpty()) {
            log.info("No records found — returning empty summary.");
            return buildEmptySummary();
        }

        // ── 1 & 2. Split records by type for focused stream operations ────────
        List<FinancialRecord> incomeRecords  = filterByType(allRecords, TransactionType.INCOME);
        List<FinancialRecord> expenseRecords = filterByType(allRecords, TransactionType.EXPENSE);

        // ── 3. Top-level totals ───────────────────────────────────────────────
        double totalIncome   = sumAmounts(incomeRecords);
        double totalExpenses = sumAmounts(expenseRecords);
        double netBalance    = totalIncome - totalExpenses;

        // ── 4. Category-wise totals ───────────────────────────────────────────
        Map<String, Double> categoryTotals = computeCategoryTotals(allRecords);

        // ── 5. Monthly summary ────────────────────────────────────────────────
        Map<Month, MonthlySummary> monthlySummary = computeMonthlySummary(allRecords);

        // ── 6. Type-wise totals ───────────────────────────────────────────────
        Map<TransactionType, Double> typeTotals = computeTypeTotals(allRecords);

        DashboardSummaryDTO summary = DashboardSummaryDTO.builder()
                .totalIncome(totalIncome)
                .totalExpenses(totalExpenses)
                .netBalance(netBalance)
                .totalRecords(allRecords.size())
                .categoryTotals(categoryTotals)
                .monthlySummary(monthlySummary)
                .typeTotals(typeTotals)
                .build();

        log.info("Dashboard summary built — income={}, expenses={}, net={}",
                totalIncome, totalExpenses, netBalance);

        return summary;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE — individual aggregation methods (each does one thing)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Filters a list of records to only those matching the given TransactionType.
     * Kept as a named method so it reads clearly in getSummary().
     */
    private List<FinancialRecord> filterByType(List<FinancialRecord> records,
                                                TransactionType type) {
        return records.stream()
                .filter(r -> type.equals(r.getType()))
                .collect(Collectors.toList());
    }

    /**
     * Sums the amount field across all records in the given list.
     * Returns 0.0 if the list is empty (no null risk).
     */
    private double sumAmounts(List<FinancialRecord> records) {
        return records.stream()
                .mapToDouble(FinancialRecord::getAmount)
                .sum();
    }

    /**
     * Groups all records by category and sums amounts within each group.
     *
     * Stream pipeline:
     *   collect → groupingBy(category) → summingDouble(amount)
     *
     * Result: { "Rent" → 25000.0, "Salary" → 80000.0, "Groceries" → 5000.0 }
     * Sorted alphabetically by category for consistent API output.
     */
    private Map<String, Double> computeCategoryTotals(List<FinancialRecord> records) {
        return records.stream()
                .collect(Collectors.groupingBy(
                        FinancialRecord::getCategory,
                        TreeMap::new,                          // TreeMap keeps keys sorted A→Z
                        Collectors.summingDouble(FinancialRecord::getAmount)
                ));
    }

    /**
     * Groups records by month and computes per-month income, expenses, and net.
     *
     * Stream pipeline:
     *   groupingBy(month) → toList per month → map each group to MonthlySummary
     *
     * Result: { JANUARY → { income: 80000, expenses: 30000, net: 50000, count: 12 }, ... }
     * Sorted by calendar month (January → December).
     */
    private Map<Month, MonthlySummary> computeMonthlySummary(List<FinancialRecord> records) {

        // Step 1: group all records by the month of their date
        Map<Month, List<FinancialRecord>> byMonth = records.stream()
                .collect(Collectors.groupingBy(
                        r -> r.getDate().getMonth(),
                        () -> new TreeMap<>(Comparator.comparingInt(Month::getValue)), // Jan→Dec order
                        Collectors.toList()
                ));

        // Step 2: transform each month's record list into a MonthlySummary
        return byMonth.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> buildMonthlySummary(entry.getValue()),
                        (a, b) -> a,               // merge function (no duplicates expected)
                        () -> new TreeMap<>(Comparator.comparingInt(Month::getValue))
                ));
    }

    /**
     * Builds a MonthlySummary from a list of records belonging to the same month.
     *
     * Splits by type, sums amounts for each side, and computes net.
     */
    private MonthlySummary buildMonthlySummary(List<FinancialRecord> monthRecords) {

        double monthIncome   = monthRecords.stream()
                .filter(r -> TransactionType.INCOME.equals(r.getType()))
                .mapToDouble(FinancialRecord::getAmount)
                .sum();

        double monthExpenses = monthRecords.stream()
                .filter(r -> TransactionType.EXPENSE.equals(r.getType()))
                .mapToDouble(FinancialRecord::getAmount)
                .sum();

        return MonthlySummary.builder()
                .income(monthIncome)
                .expenses(monthExpenses)
                .net(monthIncome - monthExpenses)
                .recordCount(monthRecords.size())
                .build();
    }

    /**
     * Groups all records by TransactionType and sums amounts per type.
     *
     * Result: { INCOME → 160000.0, EXPENSE → 60000.0 }
     */
    private Map<TransactionType, Double> computeTypeTotals(List<FinancialRecord> records) {
        return records.stream()
                .collect(Collectors.groupingBy(
                        FinancialRecord::getType,
                        Collectors.summingDouble(FinancialRecord::getAmount)
                ));
    }

    /**
     * Returns a zero-valued summary when there are no records in the system.
     * Prevents null responses and division-by-zero on the frontend.
     */
    private DashboardSummaryDTO buildEmptySummary() {
        return DashboardSummaryDTO.builder()
                .totalIncome(0.0)
                .totalExpenses(0.0)
                .netBalance(0.0)
                .totalRecords(0)
                .categoryTotals(Collections.emptyMap())
                .monthlySummary(Collections.emptyMap())
                .typeTotals(Collections.emptyMap())
                .build();
    }
}