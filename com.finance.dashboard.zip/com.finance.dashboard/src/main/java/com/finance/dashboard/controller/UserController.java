package com.finance.dashboard.controller;



import com.finance.dashboard.dto.request.UserDTO;
import com.finance.dashboard.dto.response.ApiResponse;
import com.finance.dashboard.dto.response.UserResponseDTO;
import com.finance.dashboard.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * UserController — exposes all user management endpoints.
 *
 * Base URL : /api/v1/users
 * All responses are wrapped in ApiResponse<T> for consistent structure.
 */
@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    private final UserService userService;

    // Constructor injection — no @Autowired needed
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/users
    // Register a new user
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Creates a new user account.
     *
     * @param dto Validated request body containing name, email, password, role
     * @return 201 Created with the saved user's response DTO
     */
    @PostMapping
    public ResponseEntity<ApiResponse<UserResponseDTO>> createUser(
            @Valid @RequestBody UserDTO dto) {

        UserResponseDTO created = userService.createUser(dto);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("User created successfully.", created));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/users
    // Fetch all users
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns a list of all registered users.
     *
     * @return 200 OK with list of UserResponseDTO
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<UserResponseDTO>>> getAllUsers() {

        List<UserResponseDTO> users = userService.getAllUsers();

        return ResponseEntity.ok(
                ApiResponse.success("Users fetched successfully.", users));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUT /api/v1/users/{id}
    // Update an existing user's name and role
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Updates the name and role of an existing user.
     * Email and password changes are handled through separate dedicated flows.
     *
     * @param id  Path variable — ID of the user to update
     * @param dto Validated request body with updated fields
     * @return 200 OK with updated UserResponseDTO
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<UserResponseDTO>> updateUser(
            @PathVariable Long id,
            @Valid @RequestBody UserDTO dto) {

        UserResponseDTO updated = userService.updateUser(id, dto);

        return ResponseEntity.ok(
                ApiResponse.success("User updated successfully.", updated));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DELETE /api/v1/users/{id}
    // Soft-delete — sets active = false, does NOT remove the record
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Deactivates a user account (soft delete).
     * The record is retained in the database for audit and referential integrity.
     *
     * @param id Path variable — ID of the user to deactivate
     * @return 200 OK with confirmation message (no body data)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deactivateUser(@PathVariable Long id) {

        userService.deactivateUser(id);

        return ResponseEntity.ok(
                ApiResponse.success("User deactivated successfully."));
    }
}