package com.finance.dashboard.controller;


import com.finance.dashboard.dto.response.ApiResponse;
import com.finance.dashboard.dto.response.DashboardSummaryDTO;
import com.finance.dashboard.service.DashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * DashboardController — exposes read-only aggregation endpoints.
 *
 * Base URL : /api/v1/dashboard
 *
 * Endpoints:
 *   GET /api/v1/dashboard/summary      — full summary (all metrics in one call)
 *   GET /api/v1/dashboard/income       — total income only
 *   GET /api/v1/dashboard/expenses     — total expenses only
 *   GET /api/v1/dashboard/balance      — net balance only
 *   GET /api/v1/dashboard/categories   — category-wise totals only
 *   GET /api/v1/dashboard/monthly      — monthly breakdown only
 */
@RestController
@RequestMapping("/api/v1/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/dashboard/summary
    // Full dashboard — all metrics in one response
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns a complete dashboard summary:
     *   - totalIncome, totalExpenses, netBalance, totalRecords
     *   - categoryTotals   : Map<String, Double>
     *   - monthlySummary   : Map<Month, MonthlySummary>
     *   - typeTotals       : Map<TransactionType, Double>
     *
     * @return 200 OK with DashboardSummaryDTO
     */
    @GetMapping("/summary")
    public ResponseEntity<ApiResponse<DashboardSummaryDTO>> getSummary() {

        DashboardSummaryDTO summary = dashboardService.getSummary();

        return ResponseEntity.ok(
                ApiResponse.success("Dashboard summary fetched successfully.", summary));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/dashboard/income
    // Lightweight endpoint — total income only
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns only the total income figure.
     * Useful for widgets that display a single KPI without loading the full summary.
     *
     * @return 200 OK with total income as Double
     */
    @GetMapping("/income")
    public ResponseEntity<ApiResponse<Double>> getTotalIncome() {

        double totalIncome = dashboardService.getSummary().getTotalIncome();

        return ResponseEntity.ok(
                ApiResponse.success("Total income fetched successfully.", totalIncome));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/dashboard/expenses
    // Lightweight endpoint — total expenses only
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns only the total expenses figure.
     *
     * @return 200 OK with total expenses as Double
     */
    @GetMapping("/expenses")
    public ResponseEntity<ApiResponse<Double>> getTotalExpenses() {

        double totalExpenses = dashboardService.getSummary().getTotalExpenses();

        return ResponseEntity.ok(
                ApiResponse.success("Total expenses fetched successfully.", totalExpenses));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/dashboard/balance
    // Lightweight endpoint — net balance only
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns the net balance (income - expenses).
     * A negative value indicates the account is in deficit.
     *
     * @return 200 OK with net balance as Double
     */
    @GetMapping("/balance")
    public ResponseEntity<ApiResponse<Double>> getNetBalance() {

        double netBalance = dashboardService.getSummary().getNetBalance();

        return ResponseEntity.ok(
                ApiResponse.success("Net balance fetched successfully.", netBalance));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/dashboard/categories
    // Category-wise totals only
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns a breakdown of total amounts grouped by category.
     * Sorted alphabetically: { "Groceries": 5000.0, "Rent": 25000.0, "Salary": 80000.0 }
     *
     * @return 200 OK with Map<String, Double>
     */
    @GetMapping("/categories")
    public ResponseEntity<ApiResponse<?>> getCategoryTotals() {

        var categoryTotals = dashboardService.getSummary().getCategoryTotals();

        return ResponseEntity.ok(
                ApiResponse.success("Category totals fetched successfully.", categoryTotals));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/dashboard/monthly
    // Monthly breakdown only
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns a month-by-month breakdown of income, expenses, net, and record count.
     * Only months with at least one record appear in the response.
     *
     * @return 200 OK with Map<Month, MonthlySummary>
     */
    @GetMapping("/monthly")
    public ResponseEntity<ApiResponse<?>> getMonthlySummary() {

        var monthlySummary = dashboardService.getSummary().getMonthlySummary();

        return ResponseEntity.ok(
                ApiResponse.success("Monthly summary fetched successfully.", monthlySummary));
    }
}